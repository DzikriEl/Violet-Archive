package com.example.violet_archive

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
