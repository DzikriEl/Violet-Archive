import 'package:flutter/material.dart';
import 'package:violet_archive/hero.dart';
import 'package:audioplayers/audio_cache.dart';

final player = AudioCache();

class Antimage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.red.shade50,
        appBar: AppBar(
          backgroundColor: Color(0xFF751328),
          leading: IconButton(
            icon: Icon(Icons.keyboard_arrow_left_rounded),
            onPressed: () {
              Navigator.pop(
                  context, MaterialPageRoute(builder: (context) => Nav()));
            },
          ),
          title: Text(
            'Anti Mage',
          ),
        ),
        body: Center(
          child: ListView(
            children: <Widget>[
              Container(
                child: Padding(
                  padding: EdgeInsets.only(top: 10),
                  child: Image(
                    image: AssetImage('assets/Anti-Mage_icon.jpeg'),
                  ),
                ),
              ),
              Text(
                'Anti Mage',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
              ),
              Row(
                children: [
                  Padding(
                      padding: EdgeInsets.only(left: 10),
                      child: IconButton(
                        icon: Icon(Icons.play_circle_fill),
                        onPressed: () {
                          player.play('Vo_antimage.mp3');
                        },
                      )),
                  Text('"They who live by the wand shall die by my blade."'),
                ],
              ),
              const Card(
                shape:
                    RoundedRectangleBorder(side: BorderSide(color: Colors.red)),
                child: Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Text(
                    "The monks of Turstarkuri watched the rugged valleys below their mountain monastery as wave after wave of invaders swept through the lower kingdoms. Ascetic and pragmatic, in their remote monastic eyrie they remained aloof from mundane strife, wrapped in meditation that knew no gods or elements of magic. Then came the Legion of the Dead God, crusaders with a sinister mandate to replace all local worship with their Unliving Lord`s poisonous nihilosophy. From a landscape that had known nothing but blood and battle for a thousand years, they tore the souls and bones of countless fallen legions and pitched them against Turstarkuri. The monastery stood scarcely a fortnight against the assault, and the few monks who bothered to surface from their meditations believed the invaders were but demonic visions sent to distract them from meditation. They died where they sat on their silken cushions. Only one youth survived--a pilgrim who had come as an acolyte, seeking wisdom, but had yet to be admitted to the monastery. He watched in horror as the monks to whom he had served tea and nettles were first slaughtered, then raised to join the ranks of the Dead God`s priesthood. With nothing but a few of Turstarkuri`s prized dogmatic scrolls, he crept away to the comparative safety of other lands, swearing to obliterate not only the Dead God's magic users--but to put an end to magic altogether.",
                    textAlign: TextAlign.justify,
                  ),
                ),
              ),
              new Container(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  "Anti Mage Skill",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
                ),
              ),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Mana Break',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Passive Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 10),
                        child: Image.asset('assets/manabreak_icon.png'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 10),
                        child: Column(children: [
                          Text(
                            "Burns an opponent's mana on each attack. Mana Break deals 50% of the mana burned as damage to the target. Mana Break has 50% effect if caused by illusions",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"A modified technique of the Turstarkuri monks` peaceful ways is to turn magical energies on their owner."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Blink',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Point Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/blink_icon.png'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 10),
                        child: Column(children: [
                          Text(
                            "Short distance teleportation that allows Anti-Mage to move in and out of combat.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"In his encounter with the Dead Gods, Anti-Mage learned the value of being elusive."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Counterspell',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'No Target Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 10),
                        child: Image.asset('assets/counterspell_icon.png'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Passively grants you magic resistance. Can be activated to create an anti-magic shell around you that sends any targeted spells back towards enemies instead of affecting you.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"With the proper focus, Anti-Mage turns innate resistance into calculated retaliation."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Mana Void',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Unit Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/manavoid_icon.png'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 10),
                        child: Column(children: [
                          Text(
                            "For each point of mana missing by the target unit, damage is dealt to it and surrounding enemies. The main target is also mini-stunned.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"After bringing enemies to their knees, Anti-Mage punishes them for their use of the arcane arts."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              )
            ],
          ),
        ),
      ),
    );
  }
}
