import 'package:flutter/material.dart';
import 'package:violet_archive/hero.dart';
import 'package:audioplayers/audio_cache.dart';

final player = AudioCache();

class Pudge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.red.shade50,
        appBar: AppBar(
          backgroundColor: Color(0xFF751328),
          leading: IconButton(
            icon: Icon(Icons.keyboard_arrow_left_rounded),
            onPressed: () {
              Navigator.pop(
                  context, MaterialPageRoute(builder: (context) => Nav()));
            },
          ),
          title: Text(
            'Pudge',
          ),
        ),
        body: Center(
          child: ListView(
            children: <Widget>[
              Container(
                child: Padding(
                  padding: EdgeInsets.only(top: 10),
                  child: Image(
                    image: AssetImage('assets/pudge.jpg'),
                  ),
                ),
              ),
              Text(
                'Pudge, The Butcher',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
              ),
              Row(
                children: [
                  Padding(
                      padding: EdgeInsets.only(left: 10),
                      child: IconButton(
                        icon: Icon(Icons.play_circle_fill),
                        onPressed: () {
                          player.play('Vo_pudge.mp3');
                        },
                      )),
                  Flexible(
                      child: Padding(
                    padding: EdgeInsets.only(right: 10),
                    child: Text(
                      '"When I`m through with these vermin, they`ll be fit for a pie!"',
                      textAlign: TextAlign.center,
                    ),
                  ))
                ],
              ),
              const Card(
                shape:
                    RoundedRectangleBorder(side: BorderSide(color: Colors.red)),
                child: Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Text(
                    "In the Fields of Endless Carnage, far to the south of Quoidge, a corpulent figure works tirelessly through the night--dismembering, disembowelling, piling up the limbs and viscera of the fallen that the battlefield might be clear by dawn. In this cursed realm, nothing can decay or decompose; no corpse may ever return to the earth from which it sprang, no matter how deep you dig the grave. Flocked by carrion birds who need him to cut their meals into beak-sized chunks, Pudge the Butcher hones his skills with blades that grow sharper the longer he uses them. Swish, swish, thunk. Flesh falls from the bone; tendons and ligaments part like wet paper. And while he always had a taste for the butchery, over the ages, Pudge has developed a taste for its byproduct as well. Starting with a gobbet of muscle here, a sip of blood there...before long he was thrusting his jaws deep into the toughest of torsos, like a dog gnawing at rags. Even those who are beyond fearing the Reaper, fear the Butcher.",
                    textAlign: TextAlign.justify,
                  ),
                ),
              ),
              new Container(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  "Pudge Skill",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
                ),
              ),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Meat Hook',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Point Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Meat_Hook_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Launches a bloody hook toward a unit or location. The hook will snag the first unit it encounters, dragging the unit back to Pudge and dealing damage if it is an enemy.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"The Butcher`s hook is a symbolic nightmare, its curved blade a frightening reminder of his slaughterous intent."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Rot',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Toggle Aura Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Rot_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "A toxic cloud that deals intense damage and slows movement--harming not only enemy units but Pudge himself.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"A foul odor precedes a toxic, choking gas, emanating from the Butcher`s putrid, ever-swelling mass."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Flesh Heap',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Passive Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Flesh_Heap_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Gives Pudge increased magic resistance, as well as bonus strength that increases each time Pudge kills an enemy Hero or it dies in his vicinity. Flesh Heap is retroactive, meaning it can gain charges before it is skilled, which then become active.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"The Butcher gives new meaning to the words `meat shield`."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Dismember',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Unit Ability / Channeled Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Dismember_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Pudge chows down on an enemy unit, disabling it and dealing damage over time. Pudge gets healed for the same amount he damages. Lasts longer on creeps.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"When I`m through with these vermin, they`ll be fit for a pie!"',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              )
            ],
          ),
        ),
      ),
    );
  }
}
