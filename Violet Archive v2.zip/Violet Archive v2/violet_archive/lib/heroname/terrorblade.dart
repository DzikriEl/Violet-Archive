import 'package:flutter/material.dart';
import 'package:violet_archive/hero.dart';
import 'package:audioplayers/audio_cache.dart';

final player = AudioCache();

class TerrorBlade extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.red.shade50,
        appBar: AppBar(
          backgroundColor: Color(0xFF751328),
          leading: IconButton(
            icon: Icon(Icons.keyboard_arrow_left_rounded),
            onPressed: () {
              Navigator.pop(
                  context, MaterialPageRoute(builder: (context) => Nav()));
            },
          ),
          title: Text(
            'Terrorblade',
          ),
        ),
        body: Center(
          child: ListView(
            children: <Widget>[
              Container(
                child: Padding(
                  padding: EdgeInsets.only(top: 10),
                  child: Image(
                    image: AssetImage('assets/Terrorblade.jpg'),
                  ),
                ),
              ),
              Text(
                'Terrorblade, the Demon Marauder',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
              ),
              Row(
                children: [
                  Padding(
                      padding: EdgeInsets.only(left: 5),
                      child: IconButton(
                        icon: Icon(Icons.play_circle_fill),
                        onPressed: () {
                          player.play('Vo_terror.mp3');
                        },
                      )),
                  Text('"The self-righteous shall choke on their sanctimony."'),
                ],
              ),
              const Card(
                shape:
                    RoundedRectangleBorder(side: BorderSide(color: Colors.red)),
                child: Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Text(
                    "Terrorblade is the demon marauder—an outlaw hellion whom even other demons fear. A cosmic iconoclast, he stole from the Demon Lords, ignored the codified rites that should have bound his behavior, and broke every law of the seven Infernal Regions. For his crimes, he was taught this lesson: even Hell has a hell. A short, brutal trial ensued, with many dead on all sides, and he was finally incarcerated in Foulfell, a hidden dimension where demonkind imprison their own.\n\nBut Foulfell is no normal prison. In this dark mirror of reality, demons are sentenced to gaze eternally into the twisted reflection of their own souls. But instead of suffering, Terrorblade made himself master of his own reflected worst self—a raging, thieving demon of unimaginable power. With his inner beast under sway, he destroyed the fractal prison walls and burst free to turn his terror loose upon all creation.",
                    textAlign: TextAlign.justify,
                  ),
                ),
              ),
              new Container(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  "Terrorblade Skill",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
                ),
              ),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Reflection',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Area Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Reflection_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Terrorblade brings forth an invulnerable dark reflection of all enemy heroes in a target area. Affected enemy heroes are slowed and attacked by their reflection.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"In the fractal prison of Foulfell, Terrorblade learned the truth of this old tale: you are your own worst enemy. Now it is a lesson he teaches others."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Conjure Image',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'No Target Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Conjure_Image_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Creates an illusion of Terrorblade that deals damage.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"There`s only one thing more dangerous than facing Terrorblade. Facing MORE Terrorblades!"',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Metamorphosis',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'No Target Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Metamorphosis_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Terrorblade transforms into a powerful demon with a ranged attack. Any of Terrorblade's illusions that are within 1200 range will also be transformed by Metamorphosis.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"Temper, temper. The rage rises up and takes control. Meet Terrorblade`s own worst self."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Sunder',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Unit Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Sunder_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Severs the life from both Terrorblade and a target hero, exchanging a percentage of both units' current health. Some health points must remain.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"You didn`t need that life, did you? The demon marauder steals that which you hold most dear."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              )
            ],
          ),
        ),
      ),
    );
  }
}
