import 'package:flutter/material.dart';
import 'package:violet_archive/hero.dart';
import 'package:audioplayers/audio_cache.dart';

final player = AudioCache();

class Outworld extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.red.shade50,
        appBar: AppBar(
          backgroundColor: Color(0xFF751328),
          leading: IconButton(
            icon: Icon(Icons.keyboard_arrow_left_rounded),
            onPressed: () {
              Navigator.pop(
                  context, MaterialPageRoute(builder: (context) => Nav()));
            },
          ),
          title: Text(
            'Outworld Destroyer',
          ),
        ),
        body: Center(
          child: ListView(
            children: <Widget>[
              Container(
                child: Padding(
                  padding: EdgeInsets.only(top: 10),
                  child: Image(
                    image: AssetImage('assets/outworld_destroyer.jpg'),
                  ),
                ),
              ),
              Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Text(
                    'Harbinger, The Outworld Destroyer',
                    textAlign: TextAlign.center,
                    style:
                        TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
                  )),
              Row(
                children: [
                  Padding(
                      padding: EdgeInsets.only(left: 10),
                      child: IconButton(
                        icon: Icon(Icons.play_circle_fill),
                        onPressed: () {
                          player.play('Vo_outworld.mp3');
                        },
                      )),
                  Flexible(
                      child: Padding(
                    padding: EdgeInsets.only(right: 20),
                    child: Text(
                      '"Their sanity I`ll shatter; their dreams of conquest I`ll destroy."',
                      textAlign: TextAlign.center,
                    ),
                  ))
                ],
              ),
              const Card(
                shape:
                    RoundedRectangleBorder(side: BorderSide(color: Colors.red)),
                child: Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Text(
                    "One of a lordly and magisterial race, Harbinger prowls the edge of the Void, sole surviving sentry of an outpost on the world at the rim of the abyss. From this jagged crystalline Outworld, forever on guard, he has gazed for eternities into the heavens, alert for any stirring in the bottomless night beyond the stars. Imprinted deep in the shining lattices of his intellect lies a resonant pattern akin to prophecy, a dark music implying that eventually some evil will wake out there, beyond the edges of creation, and turn its attention to our world. With his whole being focused on his vigil, Outworld Destroyer paid little attention to events closer in to the sun. But at last the clamor of the Ancients, and a sense of growing threat from within as well as without, sent him winging sunward to visit the plains of war. Harbinger's place in our own prophecies is unambiguous: he must be considered an omen of worse things to come. But his arrival in itself is bad enough.",
                    textAlign: TextAlign.justify,
                  ),
                ),
              ),
              new Container(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  "Outworld Destroyer Skill",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
                ),
              ),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Arcane Orb',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Unit Ability / Autocast',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/arcane_orb_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Adds extra pure damage to Outworld Destroyer's attacks, based on his remaining mana pool.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"Harbinger`s outworldly knowledge allows it to tap into the ebb and flow of all spiritual energy, infusing it into his being."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Astral Imprisonment',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Unit Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child:
                            Image.asset('assets/astral_imprisonment_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Places a target unit into an astral prison. The hidden unit is invulnerable and disabled. When the astral prison implodes, it deals damage to the target and steals a percentage of their max mana.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"Locked away in the pocket between this world and the Outworld, victims realize their infantile knowledge and mortality."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Essence Flux',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Passive Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Essence_Flux_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Passively grants you a chance to restore a percentage of your max mana each time you cast an ability.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"The Outworld is awash in arcane energy, inclined to diffuse through any of Harbinger`s rifts."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      "Sanity's Eclipse",
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Area Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Sanity_Eclipse_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Unleashes a psychic blast that deals to enemies based on the difference between your mana and the target's mana. Sanity's Eclipse can hit units trapped by Astral Imprisonment.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"When an Outworld crystal ruptures, cataclysmic energies are released, and the reverberations of this power are felt interdimensionally."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              )
            ],
          ),
        ),
      ),
    );
  }
}
