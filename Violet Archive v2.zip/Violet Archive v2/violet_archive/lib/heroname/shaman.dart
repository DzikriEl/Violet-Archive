import 'package:flutter/material.dart';
import 'package:violet_archive/hero.dart';
import 'package:audioplayers/audio_cache.dart';

final player = AudioCache();

class Shaman extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.red.shade50,
        appBar: AppBar(
          backgroundColor: Color(0xFF751328),
          leading: IconButton(
            icon: Icon(Icons.keyboard_arrow_left_rounded),
            onPressed: () {
              Navigator.pop(
                  context, MaterialPageRoute(builder: (context) => Nav()));
            },
          ),
          title: Text(
            'Shadow Shaman',
          ),
        ),
        body: Center(
          child: ListView(
            children: <Widget>[
              Container(
                child: Padding(
                  padding: EdgeInsets.only(top: 10),
                  child: Image(
                    image: AssetImage('assets/shaman.jpg'),
                  ),
                ),
              ),
              Text(
                'Rhasta, The Shadow Shaman',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
              ),
              Row(
                children: [
                  Padding(
                      padding: EdgeInsets.only(left: 20),
                      child: IconButton(
                        icon: Icon(Icons.play_circle_fill),
                        onPressed: () {
                          player.play('Vo_shaman.mp3');
                        },
                      )),
                  Text('"I am the intermediary between life and death."'),
                ],
              ),
              const Card(
                shape:
                    RoundedRectangleBorder(side: BorderSide(color: Colors.red)),
                child: Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Text(
                    "Born in the Bleeding Hills, Rhasta was just a starving youngling when picked up by a travelling con-man. For two pins of copper, the old con-man would tell your fortune. For three, he'd castrate your pig, for five, he'd circumcise your sons. For a good meal, he'd don his shaman garb, read from his ancient books, and lay a curse upon your enemies. His strange new youngling, part hill troll, part…something else, worked as assistant and lent an air of the exotic to the con-man's trade.\n\nAlways one step ahead of cheated customers, one town ahead of a pursuing patronage, the two trekked across the blighted lands until one day the con-man realized that the little youngling could actually do what he only pretended at. His ward had a gift—a gift that customers valued. And so the youngling Rhasta was thrust before the crowds, and the trade-name Shadow Shaman was born. The two continued from town to town, conjuring for money as Shadow Shaman's reputation grew. Eventually, the pair's duplicitous past caught up with them, and they were ambushed by a mob of swindled ex-clients. The con-man was slain, and for the first time, Rhasta used his powers for darkness, massacring the attackers. He buried his beloved master, and now uses his powers to destroy any who would seek to do him harm.",
                    textAlign: TextAlign.justify,
                  ),
                ),
              ),
              new Container(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text(
                  "Shadow Shaman Skill",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
                ),
              ),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Ether Shock',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Unit Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Ether_Shock_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Creates a cone of ethereal energy that strikes multiple enemy units.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"Originally used to open shows with the travelling con-man, Rhasta s lightning display shocks adversaries in more ways than one."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Hex',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Unit Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Hex_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Transforms an enemy unit into a harmless creature, disabling their attacks and abilities.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"Rhasta often ended performances by turning himself into a chicken - now, the humiliation is shared."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Shackles',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Unit Ability / Channeled',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Shackles_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Magically binds an enemy unit so that it cannot move or attack, while dealing damage over time.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"A self-defense incantation, Rhasta developed shackles after his master was slain in the Bleeding Hills."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              ),
              Divider(height: 10),
              Card(
                child: Column(children: [
                  ListTile(
                    title: const Text(
                      'Mass Serpent Ward',
                      style: TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      'Target Point Ability',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                          child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 20),
                        child: Image.asset('assets/Mass_Serpent_Ward_icon.jpg'),
                      )),
                      Container(
                          child: Flexible(
                              child: Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 10, 20),
                        child: Column(children: [
                          Text(
                            "Summons 10 Serpent Wards to attack enemy units and structures. The Wards are immune to magic.",
                            style: TextStyle(color: Colors.black),
                            textAlign: TextAlign.justify,
                          ),
                          Divider(height: 10),
                          Text(
                            '"Snake charming was a big part of the Shadow Shaman`s act; now Rhasta can empower the Snakes to do his bidding."',
                            style:
                                TextStyle(color: Colors.black.withOpacity(0.6)),
                            textAlign: TextAlign.justify,
                          ),
                        ]),
                      )))
                    ],
                  ),
                ]),
              )
            ],
          ),
        ),
      ),
    );
  }
}
