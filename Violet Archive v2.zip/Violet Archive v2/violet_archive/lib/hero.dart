import 'package:flutter/material.dart';
import 'package:violet_archive/about.dart';
import 'package:violet_archive/main.dart';
import 'heroname/antimage.dart';
import 'heroname/templar.dart';
import 'heroname/crystalmaiden.dart';
import 'heroname/terrorblade.dart';
import 'heroname/rubick.dart';
import 'heroname/outworld.dart';
import 'heroname/qop.dart';
import 'heroname/shaman.dart';
import 'heroname/jugger.dart';
import 'heroname/pudge.dart';
import 'heroname/phantom.dart';
import 'heroname/abaddon.dart';

class Nav extends StatefulWidget {
  @override
  _NavState createState() => _NavState();
}

class _NavState extends State<Nav> {
  var isChanged = true;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          backgroundColor: Colors.red.shade200,
          appBar: AppBar(
            backgroundColor: Color(0xFF751328),
            centerTitle: true,
            title: Text('Violet Archive',
                style: TextStyle(fontSize: 24, color: Colors.white)),
            actions: <Widget>[
              IconButton(icon: Icon(Icons.search), onPressed: () {})
            ],
          ),
          drawer: new Drawer(
              child: new ListView(
            children: <Widget>[
              new UserAccountsDrawerHeader(
                accountName: new Text(
                    isChanged ? "Ananda Reynata Saputra" : "Dzikri Faizziyan"),
                accountEmail: new Text(isChanged
                    ? "ananda065118180@unpak.ac.id"
                    : "dzikri065118123@unpak.ac.id"),
                currentAccountPicture: CircleAvatar(
                  radius: 50.0,
                  backgroundImage: AssetImage(
                      isChanged ? "assets/rey1.jpg" : "assets/dzk1.jpg"),
                ),
                decoration: new BoxDecoration(
                  image: new DecorationImage(
                      image: AssetImage("assets/bg.jpg"), fit: BoxFit.cover),
                ),
                otherAccountsPictures: <Widget>[
                  new GestureDetector(
                    child: CircleAvatar(
                        backgroundImage: AssetImage(
                            isChanged ? "assets/dzk1.jpg" : "assets/rey1.jpg")),
                    onTap: () {
                      setState(() => isChanged = !isChanged);
                    },
                  )
                ],
              ),
              new ListTile(
                title: new Text("Home"),
                trailing: new Icon(Icons.home),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => BaseLayout()),
                  );
                },
              ),
              new ListTile(
                title: new Text("About"),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Aboutt()),
                  );
                },
              ),
              new ListTile(
                  title: new Text("Exit"),
                  trailing: new Icon(Icons.close),
                  onTap: () {}),
            ],
          )),
          body: BodyLayout()),
    );
  }
}

class BodyLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return _myListView(context);
  }
}

Widget _myListView(BuildContext context) {
  final hero = [
    'Abaddon',
    'Anti Mage',
    'Crystal Maiden',
    'Juggernaut',
    'Outworld Destroyer',
    'Phantom Assassin',
    'Pudge',
    'Queen of Pain',
    'Rubick',
    'Shadow Shaman',
    'Templar Assassin',
    'Terrorblade'
  ];
  final icon = [
    'assets/abaddon_icon.jpg',
    'assets/Anti-Mage_icon.jpg',
    'assets/crystalmaiden_icon.jpg',
    'assets/Juggernaut_icon.jpg',
    'assets/outworld_destroyer_icon.jpg',
    'assets/phantom_icon.jpg',
    'assets/pudge_icon.jpg',
    'assets/qop_icon.jpg',
    'assets/rubick_icon.jpg',
    'assets/shaman_icon.jpg',
    'assets/Templar_Assassin_icon.jpg',
    'assets/Terrorblade_icon.jpg'
  ];
  final lh = [
    Abaddon(),
    Antimage(),
    CrystalMaiden(),
    Jugger(),
    Outworld(),
    Phantom(),
    Pudge(),
    QueenOfPain(),
    Rubick(),
    Shaman(),
    Templar(),
    TerrorBlade()
  ];

  return ListView.builder(
    itemCount: hero.length,
    itemBuilder: (context, index) {
      return Card(
        color: Color(0xFF541F2B),
        child: ListTile(
          leading: CircleAvatar(
            backgroundImage: AssetImage(icon[index]),
          ),
          title: Text(
            hero[index],
            style: TextStyle(color: Colors.white),
          ),
          trailing: Icon(
            Icons.keyboard_arrow_right,
            color: Colors.white,
          ),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => lh[index]));
          },
        ),
      );
    },
  );
}
