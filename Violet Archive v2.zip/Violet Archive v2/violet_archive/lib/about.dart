import 'package:flutter/material.dart';

class Aboutt extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.red.shade50,
      appBar: buildAppBar(),
      body: Padding(
        padding: EdgeInsets.fromLTRB(20, 40, 20, 20),
        child: Card(
          child: Text(
              "\nVIOLET ARCHIVE\n\n 065118123 | 065118180 \n\nLore adalah ideologi dan cerita mengenai sesuatu yang di ceritakan dari mulut ke mulut atau generasi ke generasi,aplikasi ini mengumpulkan lore dari hero dota 2 dan skill dari masing masing hero yang bersumber dari Dota 2 Wiki. Tujuan aplikasi ini untuk mempermudah para pemain Dota 2 dalam mengetahui cerita dibalik Hero yang dipakai beserta skillnya.\n\n ©TA-MOBPRO\n",
              style: TextStyle(
                  color: Colors.black, fontFamily: "Serif", fontSize: 18),
              textAlign: TextAlign.center),
        ),
      ),
    );
  }

  AppBar buildAppBar() {
    return AppBar(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
      centerTitle: true,
      title: Text('About', style: TextStyle(fontSize: 24, color: Colors.white)),
      backgroundColor: Color(0xFF751328),
      elevation: 0,
    );
  }
}
