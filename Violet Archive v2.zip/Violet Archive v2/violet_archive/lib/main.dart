import 'dart:async';
import 'package:flutter/material.dart';
import 'package:violet_archive/hero.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
    startSplash();
  }

  startSplash() async {
    var duration = const Duration(seconds: 3);
    return Timer(duration, () {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => BaseLayout()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Image.asset("assets/logo.png"),
      ),
    );
  }
}

class BaseLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: new Stack(
        children: <Widget>[
          new Container(
            decoration: new BoxDecoration(
              image: new DecorationImage(
                image: new AssetImage("assets/baselayout.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          new Center(
              child: Padding(
                  padding: EdgeInsets.only(top: 540),
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: Colors.purpleAccent,
                      ),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => Nav()));
                      },
                      child: Text("Open The Archive"))))
        ],
      ),
    );
  }
}
